import en from './en.json'
import fr from './fr.json'
import es from './es.json'
import it from './it.json'
import nl from './nl.json'
import de from './de.json'
import hr from './hr.json'

export default {
	en,
	fr,
	es,
	it,
	nl,
	de,
	hr
}
